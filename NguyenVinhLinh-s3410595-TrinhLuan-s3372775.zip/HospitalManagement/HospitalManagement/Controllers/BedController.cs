﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace HospitalManagement.Controllers
{
    [Authorize]
    public class BedController : Controller
    {
        private HospitalManagementEntities db = new HospitalManagementEntities();

        //
        // GET: /Bed/

       /* public ActionResult Index()
        {
            return View(db.Beds.ToList());
        }*/

        //
        // GET: /Bed/Details/5

        public object Index(int? page)
        {
            List<Bed> beds = db.Beds.ToList();
            var pageNumber = page ?? 1;
            var onePageOfProducts = beds.ToPagedList(pageNumber, 25);
            ViewBag.Beds = onePageOfProducts;
            return View();

        }
        public ActionResult Details(int id = 0)
        {
            Bed bed = db.Beds.Find(id);
            if (bed == null)
            {
                return HttpNotFound();
            }
            return View(bed);
        }

        //
        // GET: /Bed/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Bed/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Bed bed)
        {
            if (ModelState.IsValid)
            {
                db.Beds.Add(bed);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(bed);
        }

        //
        // GET: /Bed/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Bed bed = db.Beds.Find(id);
            if (bed == null)
            {
                return HttpNotFound();
            }
            return View(bed);
        }

        //
        // POST: /Bed/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Bed bed)
        {
            if (ModelState.IsValid)
            {
                db.Entry(bed).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(bed);
        }

        //
        // GET: /Bed/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Bed bed = db.Beds.Find(id);
            if (bed == null)
            {
                return HttpNotFound();
            }
            return View(bed);
        }

        //
        // POST: /Bed/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Bed bed = db.Beds.Find(id);
            db.Beds.Remove(bed);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        public JsonResult findBed(string term)
        {
            var bed = from s in db.Beds where s.Name.Contains(term) select new { id = s.ID, value = s.Name, ratePerDay = s.RatePerDay, type = s.BedType };
            return Json(bed, JsonRequestBehavior.AllowGet);
        }

        public JsonResult removeBed(string id)
        {
            try { 
                Bed bed = db.Beds.Find(int.Parse(id.Trim()));
                
                if (bed == null)
                {
                    var status = new { id = 0 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var visitRows = from s in db.Visits where s.BedID == bed.ID select s;
                    foreach (var row in visitRows)
                    {
                        db.Visits.Remove(row);
                    }
                    db.Beds.Remove(bed);
                    db.SaveChanges();
                    var status = new { id = 1 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                var status = new { id = 0 };
                return Json(status, JsonRequestBehavior.AllowGet);
            }
        }
    }

    
}