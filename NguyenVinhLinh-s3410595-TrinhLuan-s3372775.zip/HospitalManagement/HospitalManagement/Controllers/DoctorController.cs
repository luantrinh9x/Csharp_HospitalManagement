﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace HospitalManagement.Controllers
{
    [Authorize]
    public class DoctorController : Controller
    {
        private HospitalManagementEntities db = new HospitalManagementEntities();

        //
        // GET: /Doctor/

        /*public ActionResult Index()
        {
            return View(db.Doctors.ToList());
        }*/
        public object Index(int? page)
        {
            List<Doctor> doctors = db.Doctors.ToList();
            var pageNumber = page ?? 1;
            var onePageOfProducts = doctors.ToPagedList(pageNumber, 25);
            ViewBag.Doctors = onePageOfProducts;
            return View();

        }
        //
        // GET: /Doctor/Details/5

        public ActionResult Details(int id = 0)
        {
            Doctor doctor = db.Doctors.Find(id);
            if (doctor == null)
            {
                return HttpNotFound();
            }
            return View(doctor);
        }

        //
        // GET: /Doctor/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Doctor/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Doctor doctor)
        {
            if (ModelState.IsValid)
            {
                db.Doctors.Add(doctor);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(doctor);
        }

        //
        // GET: /Doctor/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Doctor doctor = db.Doctors.Find(id);
            if (doctor == null)
            {
                return HttpNotFound();
            }
            return View(doctor);
        }

        //
        // POST: /Doctor/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Doctor doctor)
        {
            if (ModelState.IsValid)
            {
                db.Entry(doctor).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(doctor);
        }

        //
        // GET: /Doctor/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Doctor doctor = db.Doctors.Find(id);
            if (doctor == null)
            {
                return HttpNotFound();
            }
            else
            {
                db.Doctors.Remove(doctor);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
        }

        //
        // POST: /Doctor/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Doctor doctor = db.Doctors.Find(id);
            db.Doctors.Remove(doctor);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
        public JsonResult GetJson(string term)
        {
            var doctor = from s in db.Doctors where s.Name.Contains(term) select new { id = s.ID, value = s.Name};
            return Json(doctor, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetJson2(string term)
        {
            var doctor = from s in db.Doctors where s.Name.Contains(term) select new { id = s.ID, name = s.Name, location = s.Location, phone = s.Phone };
            return Json(doctor, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetJson3(string term)
        {
            try
            {
                Doctor doctor = db.Doctors.Find(int.Parse(term.Trim()));
                if (doctor != null)
                {
                    var visitrows = from s in db.Visits where s.DoctorID == doctor.ID select s;
                    foreach (var row in visitrows)
                    {
                        db.Visits.Remove(row);
                    }
                    db.Doctors.Remove(doctor);
                    db.SaveChanges();

                    var status = new { id = 1 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
                else
                {

                    var status = new { id = 0 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {

                var status = new { id = 0 };
                return Json(status, JsonRequestBehavior.AllowGet);

            }
           
        }
    }
}