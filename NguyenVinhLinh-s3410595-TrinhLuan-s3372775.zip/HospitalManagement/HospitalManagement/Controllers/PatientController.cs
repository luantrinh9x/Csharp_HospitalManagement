﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace HospitalManagement.Controllers
{
    [Authorize]
    public class PatientController : Controller
    {
        private HospitalManagementEntities db = new HospitalManagementEntities();

        //
        // GET: /Patient/
        /*
        public ActionResult Index()
        {
            return View(db.Patients.ToList());
        }
        */
        public object Index(int? page)
        {
            List<Patient> patients = db.Patients.ToList();
            
            var pageNumber = page ?? 1;
            var onePageOfProducts = patients.ToPagedList(pageNumber, 25);
            ViewBag.Patients = onePageOfProducts;
            return View();

        }
        //
        // GET: /Patient/Details/5

        public ActionResult Details(int id = 0)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
            {
                return HttpNotFound();
            }
            return View(patient);
        }

        //
        // GET: /Patient/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Patient/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Patient patient)
        {
            if (ModelState.IsValid)
            {
                patient.DateOfReg = DateTime.Now;
                db.Patients.Add(patient);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(patient);
        }

        //
        // GET: /Patient/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
            {
                return HttpNotFound();
            }
            return View(patient);
        }

        //
        // POST: /Patient/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Patient patient)
        {
            Patient temp = db.Patients.Find(patient.ID);
            temp.Name = patient.Name;
            temp.Location = patient.Location;
            temp.DOB = patient.DOB;
            temp.Phone = patient.Phone;

            if (ModelState.IsValid)
            {
                db.Entry(temp).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(patient);
        }

        //
        // GET: /Patient/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Patient patient = db.Patients.Find(id);
            if (patient == null)
            {
                return HttpNotFound();
            }
            return View(patient);
        }

        //
        // POST: /Patient/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Patient patient = db.Patients.Find(id);
            db.Patients.Remove(patient);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        public JsonResult searchPatient(string term)
        {
            try
            {
                var patient = from s in db.Patients where s.Name.Contains(term) select new { id = s.ID, value = s.Name, location = s.Location, phone = s.Phone, DOB = s.DOB, DOR = s.DateOfReg};

                return Json(patient, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return null;
            }
        }
        public JsonResult removePatient(string id)
        {
            try
            {
                Patient patient = db.Patients.Find(int.Parse(id.Trim()));
                if (patient != null)
                {
                    var visitrows = from s in db.Visits where s.PatientID == patient.ID select s;
                    foreach (var row in visitrows)
                    {
                        db.Visits.Remove(row);
                    }
                    db.Patients.Remove(patient);
                    db.SaveChanges();
                    var status = new { id = 1 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var status = new { id = 0 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                var status = new { id = 0 };
                return Json(status, JsonRequestBehavior.AllowGet);
            }
        }
    }
}