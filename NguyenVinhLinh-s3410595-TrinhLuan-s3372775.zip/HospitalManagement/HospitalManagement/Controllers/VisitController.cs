﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
namespace HospitalManagement.Controllers
{
    [Authorize]
    public class VisitController : Controller
    {
        private HospitalManagementEntities db = new HospitalManagementEntities();

        //
        // GET: /Visit/

       /* public ActionResult Index()
        {
            var visits = db.Visits.Include(v => v.Bed).Include(v => v.Doctor).Include(v => v.Patient);
            return View(visits.ToList());
        }*/
        public object Index(int? page)
        {
            List<Visit> visits = db.Visits.ToList();
            var pageNumber = page ?? 1;
            var onePageOfProducts = visits.ToPagedList(pageNumber, 25);
            ViewBag.Visits = onePageOfProducts;
            return View();
        }

        //
        // GET: /Visit/Details/5

        public ActionResult Details(int id = 0)
        {
            Visit visit = db.Visits.Find(id);
            if (visit == null)
            {
                return HttpNotFound();
            }
            return View(visit);
        }

        //
        // GET: /Visit/Create

        public ActionResult Create()
        {
            var validBed = from bed in db.Beds 
                           let occupiedBeds = from a in db.Visits where a.BedID != null && a.DateOut == null select a.BedID
                               where !occupiedBeds.Contains(bed.ID) select bed;

            var validPatient = from patients in db.Patients
                               let stayedPatient = from p in db.Visits where p.BedID != null && p.DateOut == null select p.PatientID
                               where !stayedPatient.Contains(patients.ID)
                               select patients;
            ViewBag.BedID = new SelectList(validBed, "ID", "Name");
            ViewBag.DoctorID = new SelectList(db.Doctors, "ID", "Name");
            ViewBag.PatientID = new SelectList(validPatient, "ID", "Name");
            return View();
        }

        //
        // POST: /Visit/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Visit visit)
        {
            if (visit.PatientType == false)
            {
                visit.BedID = null;
            }
            if (ModelState.IsValid)
            {
                visit.DateIn = DateTime.Now;
                db.Visits.Add(visit);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BedID = new SelectList(db.Beds, "ID", "Name", visit.BedID);
            ViewBag.DoctorID = new SelectList(db.Doctors, "ID", "Name", visit.DoctorID);
            ViewBag.PatientID = new SelectList(db.Patients, "ID", "Name", visit.PatientID);
            return View(visit);
        }

        //
        // GET: /Visit/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Visit visit = db.Visits.Find(id);
            if (visit == null)
            {
                return HttpNotFound();
            }
            ViewBag.BedID = new SelectList(db.Beds, "ID", "Name", visit.BedID);
            ViewBag.DoctorID = new SelectList(db.Doctors, "ID", "Name", visit.DoctorID);
            ViewBag.PatientID = new SelectList(db.Patients, "ID", "Name", visit.PatientID);
            return View(visit);
        }

        //
        // POST: /Visit/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Visit visit)
        {
            if (ModelState.IsValid)
            {
                if (visit.PatientType == false)
                {
                    visit.BedID = null;
                    visit.DateOut = null;
                }
                db.Entry(visit).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BedID = new SelectList(db.Beds, "ID", "Name", visit.BedID);
            ViewBag.DoctorID = new SelectList(db.Doctors, "ID", "Name", visit.DoctorID);
            ViewBag.PatientID = new SelectList(db.Patients, "ID", "Name", visit.PatientID);
            return View(visit);
        }

        //
        // GET: /Visit/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Visit visit = db.Visits.Find(id);
            if (visit == null)
            {
                return HttpNotFound();
            }
            return View(visit);
        }

        //
        // POST: /Visit/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Visit visit = db.Visits.Find(id);
            db.Visits.Remove(visit);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        public JsonResult searchVisit(string term)
        {
               /*var visit = from v in db.Visits
                           join d in db.Doctors on v.DoctorID equals d.ID
                           join p in db.Patients on v.PatientID equals p.ID
                           join b in db.Beds on v.BedID equals b.ID 
                           where d.Name.Contains(term) || p.Name.Contains(term) || b.Name.Contains(term)
                           select new { id = v.ID, /*DoctorName = d.Name , PatientName = p.Name, BedName = b.Name, type = v.PatientType, DateIn = v.DateIn, DateOut = v.DateOut, sym = v.Symtoms, dis = v.Disease, tre = v.Treatment};*/
            //it works, it will find all row that has bed name
            var visit = (from v in db.Visits
                         from d in db.Doctors
                         from p in db.Patients
                         from b in db.Beds
                         where v.DoctorID == d.ID && v.PatientID == p.ID && (v.BedID == b.ID) && (d.Name.Contains(term) || p.Name.Contains(term) || b.Name.Contains(term))
                         select new { id = v.ID, doctorName = d.Name, patientName = p.Name, bedName = b.Name, type = v.PatientType, datein = v.DateIn, dateout = v.DateOut, sym = v.Symtoms, dis = v.Disease, tre = v.Treatment })
                        .Union(
                        from v in db.Visits
                        from d in db.Doctors
                        from p in db.Patients
                        from b in db.Beds
                        where v.DoctorID == d.ID && v.PatientID == p.ID && (v.BedID == null) && (d.Name.Contains(term) || p.Name.Contains(term))
                        select new { id = v.ID, doctorName = d.Name, patientName = p.Name, bedName = "", type = v.PatientType, datein = v.DateIn, dateout = v.DateOut, sym = v.Symtoms, dis = v.Disease, tre = v.Treatment }
                        );
           
            //it should find all row that dont have bed name but contain term in patient name and doctor name
            var visit2 = from v in db.Visits
                         from d in db.Doctors
                         from p in db.Patients
                         from b in db.Beds
                         where v.DoctorID == d.ID && v.PatientID == p.ID && (v.BedID == null) && (d.Name.Contains(term) || p.Name.Contains(term))
                         select new { id = v.ID, doctorName = d.Name, patientName = p.Name, bedName = "" , type = v.PatientType, datein = v.DateIn, dateout = v.DateOut, sym = v.Symtoms, dis = v.Disease, tre = v.Treatment };
          //  visit.Union(visit2);
            return Json(visit, JsonRequestBehavior.AllowGet);


        }

        public ActionResult Create2()
        {
            /*var validBed = from bed in db.Beds
                           let occupiedBeds = from a in db.Visits where a.BedID != null && a.DateOut == null select a.BedID
                           where !occupiedBeds.Contains(bed.ID)
                           select bed;
            ViewBag.BedID = new SelectList(validBed, "ID", "Name");
            ViewBag.DoctorID = new SelectList(db.Doctors, "ID", "Name");
            ViewBag.PatientID = new SelectList(db.Patients, "ID", "Name");*/
            return View();
        }

        public JsonResult Checkout(string id)
        {
            try
            {
                Visit visit = db.Visits.Find(int.Parse(id.Trim()));
                Bed bed = db.Beds.Find(visit.BedID);
                if (visit != null && visit.DateOut == null)
                {
                    visit.DateOut = DateTime.Now;
                    db.SaveChanges();
                    TimeSpan ts = (TimeSpan)(visit.DateOut - visit.DateIn);
                    var money = (int) Math.Ceiling(ts.TotalDays) * bed.RatePerDay;
                    var status = new { id = 1,day = (int) Math.Ceiling(ts.TotalDays) , money = money};
                    return Json(status, JsonRequestBehavior.AllowGet); 
                }
                else
                {
                    var status = new { id = 0 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
            }

            catch
            {
                var status = new { id = 0 };
                return Json(status, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult removeVisit(string id)
        {
            try
            {
                Visit visit = db.Visits.Find(int.Parse(id.Trim()));
                if (visit == null)
                {
                    var status = new { id = 0 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    db.Visits.Remove(visit);
                    db.SaveChanges();
                    var status = new { id = 1 };
                    return Json(status, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                var status = new { id = 0 };
                return Json(status, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult searchValidPatient(string term)
        {
            var validPatient = from patients in db.Patients
                               let stayedPatient = from p in db.Visits where p.BedID != null && p.DateOut == null select p.PatientID
                               where !stayedPatient.Contains(patients.ID)
                               select new { id = patients.ID, value = patients.Name  };
            return Json(validPatient, JsonRequestBehavior.AllowGet);
        }
    }
}