use HospitalManagement
Create table Bed(
ID int PRIMARY KEY IDENTITY(1,1),
Name varchar(20) NOT NULL,
RatePerDay real,
BedType int NOT NULL,
)
