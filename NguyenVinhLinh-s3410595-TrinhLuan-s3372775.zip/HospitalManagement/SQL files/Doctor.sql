Use HospitalManagement
Create table Doctor(
ID int Primary Key IDENTITY(1,1),
Name varchar(30) NOT NULL,
Location varchar(100),
Phone int
)