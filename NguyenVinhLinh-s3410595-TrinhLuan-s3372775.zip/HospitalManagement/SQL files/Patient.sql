USE HospitalManagement

Create table Patient(
ID int IDENTITY (1,1) PRIMARY KEY,
Name varchar(30) NOT NULL,
Location varchar(100),
DOB date,
Phone int,
DateOfReg date
)

