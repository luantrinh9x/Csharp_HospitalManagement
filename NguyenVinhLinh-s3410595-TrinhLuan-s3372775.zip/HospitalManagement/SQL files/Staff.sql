use HospitalManagement
Create table Staff(
ID int primary key identity (1,1),
UserName varchar (20) NOT NULL,
Password varchar (30)
)