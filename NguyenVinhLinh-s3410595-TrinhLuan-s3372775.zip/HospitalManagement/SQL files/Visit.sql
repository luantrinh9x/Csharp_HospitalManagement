use HospitalManagement
Create table Visit(
ID int Primary key IDENTITY(1,1),
DoctorID int,
BedID int,
PatientID int,
PatientType bit,
DateIn date,
DateOut date,
Symtoms varchar(1000),
Disease varchar(1000),
Treatment varchar(1000)
)